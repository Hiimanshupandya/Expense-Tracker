<?php defined("BASEPATH") OR exit("No direct script access allowed");

class Goal extends CI_Controller {
  	function __construct() {
	    parent::__construct();
	    $this->load->model("Goal_model"); 
		if(true==1){
			is_login(); 
			$this->user_id =isset($this->session->get_userdata()['user_details'][0]->id)?$this->session->get_userdata()['user_details'][0]->id:'1';
		}else{ 	
			$this->user_id =1;
		}
  	}

  	/**
      * This function is used to view page
      */
  	public function index() {   
  		if(CheckPermission("expenses", "all_read,own_read")){
			$data["view_data"]= $this->Goal_model->get_data();

            $data["view_saving"]= $this->Goal_model->get_data_saving();
            $data["view_saving_redim"]= $this->Goal_model->get_data_saving_redim();
            
            $data["total_saving"] =  $data["view_saving"][0]->amount -$data["view_saving_redim"][0]->amount;
         
			$this->load->view("include/header");
			$this->load->view("index",$data);
			$this->load->view("include/footer");
		} else {
			$this->session->set_flashdata('messagePr', 'You don\'t have permission to access.');
            redirect( base_url().'user/profile', 'refresh');
		}
  	}

  	
    public function add_redeem() {
        $goal_id = $_GET['id'];
        $amount_goal =  $_GET['amount'];
        $login_user_id=$this->user_id;

        $data["view_saving"]= $this->Goal_model->get_data_saving();
        $data["view_saving_redim"]= $this->Goal_model->get_data_saving_redim();
            
        $total_saving = $data["view_saving"][0]->amount -$data["view_saving_redim"][0]->amount;  

        if($total_saving >= $amount_goal){
            
			$data = array( 
			    'user_id' =>  $login_user_id, 
			    'date' =>  "", 
			    'description' =>  "Goal redeem",
			    'amount' =>   $amount_goal,
			    'redim'	=>  1
			);
			$this->db->insert('saving_amouny', $data);


			$data_update = array( 
				'status_redeem' => 1, 
			);
			$this->db->where('goal_id', $goal_id);
			$this->db->update('goal', $data_update);



            $this->session->set_flashdata('message', 'Your Goal Successfully..');
			redirect('goal');

        }else{

        	$this->session->set_flashdata('message', 'Your Saving Amount Not Completed..');
      		redirect('goal');
        }



    } 
  	/**
      * This function is used to Add and update data
      */
	public function add_edit() {	
		$data = $this->input->post();
		
		if($this->input->post('id')) {
			unset($data['submit']);
			unset($data['save']);
			unset($data['id']);
			$this->Goal_model->updateRow('goal', 'goal_id', $this->input->post('id'), $data);
			$this->session->set_flashdata('message', 'Your data updated Successfully..');
      		redirect('goal');
		} else { 
			unset($data['submit']);
			unset($data['save']);
			$data['user_id']=$this->user_id;
			$this->Goal_model->insertRow('goal', $data);
			$this->session->set_flashdata('message', 'Your data inserted Successfully..');
			redirect('goal');
		}
	}
	
	/**
      * This function is used to show popup for add and update
      */
	public function get_modal() {
		if($this->input->post('id')){
			$data['data']= $this->Goal_model->Get_data_id($this->input->post('id'));
      		echo $this->load->view('add_update', $data, true);
	    } else {
	      	echo $this->load->view('add_update', '', true);
	    }
	    exit;
	}

	
	/**
      * This function is used to delete multiple records form table
      * @param : $ids is array if record id
      */
  	public function delete($ids) {
		$idsArr = explode('-', $ids);
		foreach ($idsArr as $key => $value) {
			$this->Goal_model->delete_data($value);		
		}
		redirect(base_url().'goal', 'refresh');
  	}

  	/**
      * This function is used to delete single record form table
      * @param : $id is record id
      */
  	public function delete_data($id) { 
		$this->Goal_model->delete_data($id);
	    $this->session->set_flashdata('message', 'Your data deleted Successfully..');
	    redirect('goal');
  	}

	/**
      * This function is used to create data for server side datatable
      */
  	public function ajx_data(){
		$primaryKey = 'goal_id';
		$table 		= 'goal';
		$columns 	= array(
array( 'db' => '`goal`.`goal_id`', 'dt' => 0, 'field' => 'goal_id' 	 ),
 array( 'db' => '`goal`.`date`', 'dt' => 1, 'field' => 'date' ),
 array( 'db' => '`goal`.`description`', 'dt' => 2, 'field' => 'description' ),
 array( 'db' => '`goal`.`amount`', 'dt' => 3, 'field' => 'amount' ));
		$joinQuery 	= "FROM goal";
		$aminkhan 	= '@banarsiamin@';

		$where = '';
		if($this->input->get('dateRange')) {
			$date = explode(' - ', $this->input->get('dateRange'));
			$where = " DATE_FORMAT(`$table`.`".$this->input->get('columnName')."`, '%Y/%m/%d') >= '".date('Y/m/d', strtotime($date[0]))."' AND  DATE_FORMAT(`$table`.`".$this->input->get('columnName')."`, '%Y/%m/%d') <= '".date('Y/m/d', strtotime($date[1]))."' ";
		}

		$sql_details = array(
			'user' => $this->db->username,
			'pass' => $this->db->password,
			'db'   => $this->db->database,
			'host' => $this->db->hostname
		);

		if(CheckPermission($table, "all_read")){}
		else if(CheckPermission($table, "own_read") && CheckPermission($table, "all_read")!=true){$where	.= "`$table`.`user_id`=".$this->user_id;}

		$output_arr = SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery, $where);
		foreach ($output_arr['data'] as $key => $value) 
		{
			$output_arr['data'][$key][0] = '<input type="checkbox" name="selData" value="'.$output_arr['data'][$key][0].'">';
			$id = $output_arr['data'][$key][count($output_arr['data'][$key])  - 1];
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] = '';
			if(CheckPermission($table, "all_update")){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a sty id="btnEditRow" class="modalButton mClass"  href="javascript:;" type="button" data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
			}else if(CheckPermission($table, "own_update") && (CheckPermission($table, "all_update")!=true)){
				$user_id =getRowByTableColomId($table,$id,'id','user_id');
				if($user_id==$this->user_id){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a sty id="btnEditRow" class="modalButton mClass"  href="javascript:;" type="button" data-src="'.$id.'" title="Edit"><i class="fa fa-pencil" data-id=""></i></a>';
				}
			}
			
			if(CheckPermission($table, "all_delete")){

			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a data-toggle="modal" class="mClass" style="cursor:pointer;"  data-target="#cnfrm_delete" title="delete" onclick="setId('.$id.', \''.$table.'\')"><i class="fa fa-trash-o" ></i></a>';}
			else if(CheckPermission($table, "own_delete") && (CheckPermission($table, "all_delete")!=true)){
				$user_id =getRowByTableColomId($table,$id,'id','user_id');
				if($user_id==$this->user_id){
			$output_arr['data'][$key][count($output_arr['data'][$key])  - 1] .= '<a data-toggle="modal" class="mClass" style="cursor:pointer;"  data-target="#cnfrm_delete" title="delete" onclick="setId('.$id.', \''.$table.'\')"><i class="fa fa-trash-o" ></i></a>';
				}
			}
		}
		echo json_encode($output_arr);
  	}

  	/**
      * This function is used to filter list view data by date range
      */
  	public function getFilterdata(){
  		$where = '';
		if($this->input->post('dateRange')) {
			$date = explode(' - ', $this->input->post('dateRange'));
			$where = " DATE_FORMAT(`goal`.`".$this->input->post('colName')."`, '%Y/%m/%d') >= '".date('Y/m/d', strtotime($date[0]))."' AND  DATE_FORMAT(`goal`.`".$this->input->post('colName')."`, '%Y/%m/%d') <= '".date('Y/m/d', strtotime($date[1]))."' ";
		}
		$data["view_data"]= $this->Goal_model->get_data($where);
		echo $this->load->view("tableData",$data, true);
		die;
  	}
}
?>